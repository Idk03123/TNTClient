# TNT Client (Launcher MVP)

This is a Windows-only Minecraft launcher starter project (WPF + .NET 8) that:
- Uses **instances** (each instance has its own game folder)
- Lets you **enable/disable .jar mods** by moving them between `mods/` and `mods_disabled/`
- Can **download & launch vanilla versions** automatically
- Can **install Fabric Loader** into an instance (so Fabric mods can work)

It uses **CmlLib.Core** to download/launch Minecraft and install Fabric.  
Docs for Fabric installer API are here: https://alphabs.gitbook.io/cmllib/cmllib.core/installer/fabric-installer

> Note: This MVP uses **offline login** (username only). Singleplayer works; online-mode multiplayer requires Microsoft login (you can add that next).

---

## Step-by-step (what to do)

### 1) Install prerequisites
1. Install **Visual Studio 2022** (Community is fine)
2. In the installer, select workload: **“.NET desktop development”**
3. Install **.NET 8 SDK** (VS usually includes it)

### 2) Open the project
1. Extract this zip anywhere
2. Open `TNTClient.sln` in Visual Studio
3. Build: `Build > Build Solution`

If NuGet restore fails:
- Right click solution > **Restore NuGet Packages**
- Or: `Tools > NuGet Package Manager > Manage NuGet Packages for Solution...` and ensure `CmlLib.Core` is installed.

### 3) Run it
Press **F5**.

### 4) Create an instance
- Go to **Play** tab
- Pick a version (Refresh if needed)
- Click **New**
- Select the instance in the dropdown

### 5) Vanilla launch
- Loader: **Vanilla**
- Click **Launch**
- First time will download files; later it launches faster.

### 6) Fabric + mods
- Loader: **Fabric**
- Click **Install Loader** (once per Minecraft version per instance)
- Go to **Mods** tab
- Click **Add .jar** (pick a Fabric mod jar)
- Toggle **Enabled** on/off
- Go back to **Play** and click **Launch**

---

## Where files are stored
`%AppData%\TNTClient\instances\<instance>\game\`

Mods:
- Enabled: `mods\`
- Disabled: `mods_disabled\`

---

## Next upgrades you can add
- Microsoft login (online multiplayer)
- Shared caches for assets/libraries across instances
- Mod metadata from Modrinth/CurseForge (versions dropdown like your screenshot)
- Better UI polish (rounded toggles, per-mod menu)

