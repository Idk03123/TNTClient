using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace TNTClient.App
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            // Catch UI thread crashes
            this.DispatcherUnhandledException += OnDispatcherUnhandledException;

            // Catch background thread crashes
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;

            base.OnStartup(e);
        }

        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            ShowCrash("UI thread crash", e.Exception);
            e.Handled = true; // prevents instant close so you can read it
        }

        private void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            var ex = e.ExceptionObject as Exception ?? new Exception("Unknown unhandled exception");
            ShowCrash("Unhandled exception", ex);
        }

        private void ShowCrash(string title, Exception ex)
        {
            try
            {
                var dir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "TNTClient");
                Directory.CreateDirectory(dir);

                var logPath = Path.Combine(dir, "crash.log");
                File.AppendAllText(logPath,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {title}\n{ex}\n\n",
                    Encoding.UTF8);

                MessageBox.Show(
                    $"{title}\n\n{ex.Message}\n\nFull log:\n{logPath}",
                    "TNTClient Crash",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
            catch
            {
                // If logging fails, still try to show something
                MessageBox.Show(ex.ToString(), "TNTClient Crash (logging failed)");
            }
        }
    }
}