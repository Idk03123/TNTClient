using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using Microsoft.Win32;
using TNTClient.App.Models;
using TNTClient.App.Services;
using TNTClient.App.Utils;
using TNTClient.App.ViewModels;

namespace TNTClient.App;

public sealed class MainViewModel : ObservableObject
{
    private readonly ProfileStore _store = new();
    private readonly InstanceService _instances = new();
    private readonly ModService _mods = new();
    private readonly MinecraftService _mc = new();

    public ObservableCollection<InstanceProfile> Instances { get; } = new();

    private InstanceProfile? _selectedInstance;
    public InstanceProfile? SelectedInstance
    {
        get => _selectedInstance;
        set
        {
            if (Set(ref _selectedInstance, value))
            {
                ModsHint = value is null ? "Create/select an instance." : $"Instance: {value.Name}";
                RefreshMods();
                RaiseCanExecutes();
            }
        }
    }

    public ObservableCollection<string> AvailableVanillaVersions { get; } = new();

    private string _selectedVanillaVersion = "latest-release";
    public string SelectedVanillaVersion
    {
        get => _selectedVanillaVersion;
        set { Set(ref _selectedVanillaVersion, value); LaunchHint = BuildLaunchHint(); RaiseCanExecutes(); }
    }

    public ObservableCollection<string> LoaderOptions { get; } = new() { "Vanilla", "Fabric" };

    private string _selectedLoader = "Vanilla";
    public string SelectedLoader
    {
        get => _selectedLoader;
        set { Set(ref _selectedLoader, value); LaunchHint = BuildLaunchHint(); RaiseCanExecutes(); }
    }

    private string _username = "Player";
    public string Username
    {
        get => _username;
        set { Set(ref _username, value); }
    }

    private double _progressPercent;
    public double ProgressPercent
    {
        get => _progressPercent;
        set { Set(ref _progressPercent, value); }
    }

    private string _progressText = "";
    public string ProgressText
    {
        get => _progressText;
        set { Set(ref _progressText, value); }
    }

    private string _logText = "";
    public string LogText
    {
        get => _logText;
        set { Set(ref _logText, value); }
    }

    private string _statusText = "Ready";
    public string StatusText
    {
        get => _statusText;
        set { Set(ref _statusText, value); }
    }

    private string _launchHint = "";
    public string LaunchHint
    {
        get => _launchHint;
        set { Set(ref _launchHint, value); }
    }

    public string DataRoot => AppPaths.DataRoot;

    private int _ramGb = 4;
    public int RamGb
    {
        get => _ramGb;
        set { Set(ref _ramGb, value); }
    }

    private string _customJavaPath = "";
    public string CustomJavaPath
    {
        get => _customJavaPath;
        set { Set(ref _customJavaPath, value); }
    }

    public string SettingsHint =>
        "If Minecraft fails to start, set Custom Java Path to javaw.exe. For 1.20.5+ you need Java 21. " +
        "CmlLib.Core can install Java runtime automatically in many cases, but custom Java helps when Java isn't found.";

    // Mods
    private string _modSearch = "";
    public string ModSearch
    {
        get => _modSearch;
        set { if (Set(ref _modSearch, value)) ApplyModFilter(); }
    }

    private string _modsHint = "Create/select an instance.";
    public string ModsHint
    {
        get => _modsHint;
        set { Set(ref _modsHint, value); }
    }

    public ObservableCollection<ModRowViewModel> Mods { get; } = new();
    public ObservableCollection<ModRowViewModel> FilteredMods { get; } = new();

    // Commands
    public RelayCommand RefreshVersionsCommand { get; }
    public RelayCommand NewInstanceCommand { get; }
    public RelayCommand DeleteInstanceCommand { get; }
    public RelayCommand OpenInstanceFolderCommand { get; }
    public RelayCommand LaunchCommand { get; }
    public RelayCommand InstallLoaderCommand { get; }
    public RelayCommand RefreshModsCommand { get; }
    public RelayCommand AddModCommand { get; }
    public RelayCommand OpenModsFolderCommand { get; }
    public RelayCommand ToggleModCommand { get; }
    public RelayCommand BrowseJavaCommand { get; }
    public RelayCommand OpenDataRootCommand { get; }

    public MainViewModel()
    {
        RefreshVersionsCommand = new RelayCommand(_ => _ = RefreshVersionsAsync());
        NewInstanceCommand = new RelayCommand(_ => NewInstance());
        DeleteInstanceCommand = new RelayCommand(_ => DeleteSelected(), _ => SelectedInstance != null);
        OpenInstanceFolderCommand = new RelayCommand(_ => OpenFolder(SelectedInstance?.RootDir), _ => SelectedInstance != null);
        LaunchCommand = new RelayCommand(_ => _ = LaunchAsync(), _ => SelectedInstance != null && !string.IsNullOrWhiteSpace(SelectedVanillaVersion));
        InstallLoaderCommand = new RelayCommand(_ => _ = InstallLoaderAsync(), _ => SelectedInstance != null && SelectedLoader == "Fabric");
        RefreshModsCommand = new RelayCommand(_ => RefreshMods(), _ => SelectedInstance != null);
        AddModCommand = new RelayCommand(_ => AddModJar(), _ => SelectedInstance != null);
        OpenModsFolderCommand = new RelayCommand(_ => OpenFolder(SelectedInstance?.ModsDir), _ => SelectedInstance != null);
        ToggleModCommand = new RelayCommand(p => ToggleMod(p as ModRowViewModel), _ => SelectedInstance != null);
        BrowseJavaCommand = new RelayCommand(_ => BrowseJava());
        OpenDataRootCommand = new RelayCommand(_ => OpenFolder(AppPaths.DataRoot));

        LoadProfiles();
        LaunchHint = BuildLaunchHint();

        // Load versions in background
        _ = RefreshVersionsAsync();
    }

    private void RaiseCanExecutes()
    {
        DeleteInstanceCommand.RaiseCanExecuteChanged();
        OpenInstanceFolderCommand.RaiseCanExecuteChanged();
        LaunchCommand.RaiseCanExecuteChanged();
        InstallLoaderCommand.RaiseCanExecuteChanged();
        RefreshModsCommand.RaiseCanExecuteChanged();
        AddModCommand.RaiseCanExecuteChanged();
        OpenModsFolderCommand.RaiseCanExecuteChanged();
        ToggleModCommand.RaiseCanExecuteChanged();
    }

    private void LoadProfiles()
    {
        Instances.Clear();
        var loaded = _store.Load();

        // Fix RootDir if empty (older saves)
        foreach (var p in loaded)
        {
            if (string.IsNullOrWhiteSpace(p.RootDir))
            {
                p.RootDir = Path.Combine(AppPaths.InstancesRoot, p.Name + "-" + p.Id[..6]);
                Directory.CreateDirectory(p.RootDir);
            }
            _instances.EnsureDirs(p);
            Instances.Add(p);
        }

        SelectedInstance = Instances.FirstOrDefault();

        if (SelectedInstance is null)
        {
            // Auto create a starter instance
            var starter = _instances.Create("My Instance");
            Instances.Add(starter);
            SelectedInstance = starter;
            SaveProfiles();
        }
    }

    private void SaveProfiles()
    {
        _store.Save(Instances);
    }

    private async Task RefreshVersionsAsync()
    {
        try
        {
            StatusText = "Fetching versions...";
            AppendLog("Fetching vanilla version list...");
            var versions = await _mc.GetVanillaVersionNamesAsync();

            Application.Current.Dispatcher.Invoke(() =>
            {
                AvailableVanillaVersions.Clear();
                foreach (var v in versions.Take(200)) // keep UI snappy
                    AvailableVanillaVersions.Add(v);

                // pick a default if current not in list
                if (!AvailableVanillaVersions.Contains(SelectedVanillaVersion))
                    SelectedVanillaVersion = AvailableVanillaVersions.FirstOrDefault() ?? "latest-release";
            });

            AppendLog($"Loaded {versions.Count} versions (showing top 200).");
            StatusText = "Ready";
        }
        catch (Exception ex)
        {
            AppendLog("Failed to fetch versions: " + ex.Message);
            StatusText = "Error";
        }
    }

    private void NewInstance()
    {
        var name = "Instance " + (Instances.Count + 1);
        var created = _instances.Create(name);
        created.VanillaVersion = SelectedVanillaVersion;
        created.LastUsername = Username;
        Instances.Add(created);
        SelectedInstance = created;
        SaveProfiles();
    }

    private void DeleteSelected()
    {
        if (SelectedInstance is null) return;

        var result = MessageBox.Show(
            $"Delete instance '{SelectedInstance.Name}'? This removes its game files/mods.",
            "Delete Instance",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (result != MessageBoxResult.Yes) return;

        var toDelete = SelectedInstance;
        Instances.Remove(toDelete);
        _instances.Delete(toDelete);

        SelectedInstance = Instances.FirstOrDefault();
        SaveProfiles();
    }

    private async Task InstallLoaderAsync()
    {
        if (SelectedInstance is null) return;

        try
        {
            StatusText = "Installing loader...";
            AppendLog($"Installing Fabric for {SelectedVanillaVersion}...");

            var log = new Progress<string>(AppendLog);
            var installedVersionName = await _mc.EnsureFabricInstalledAsync(SelectedInstance, SelectedVanillaVersion, log);
            SelectedInstance.InstalledLoaderVersionName = installedVersionName;

            SaveProfiles();
            AppendLog("Fabric install done.");
            StatusText = "Ready";
        }
        catch (Exception ex)
        {
            AppendLog("Fabric install failed: " + ex.Message);
            StatusText = "Error";
        }
    }

    private async Task LaunchAsync()
    {
        if (SelectedInstance is null) return;

        try
        {
            StatusText = "Preparing...";
            ProgressPercent = 0;
            ProgressText = "";
            AppendLog($"Launching {SelectedLoader} {SelectedVanillaVersion}...");

            SelectedInstance.Loader = SelectedLoader;
            SelectedInstance.VanillaVersion = SelectedVanillaVersion;
            SelectedInstance.LastUsername = Username;
            SaveProfiles();

            var log = new Progress<string>(AppendLog);

            var proc = await _mc.CreateProcessAsync(
                SelectedInstance,
                SelectedVanillaVersion,
                SelectedLoader,
                Username,
                RamGb,
                string.IsNullOrWhiteSpace(CustomJavaPath) ? null : CustomJavaPath,
                log);
// start and pipe logs
            proc.Start();
            StatusText = "Running";

            proc.OutputDataReceived += (_, e) =>
            {
                if (!string.IsNullOrWhiteSpace(e.Data))
                    AppendLog(e.Data!);
            };
            proc.ErrorDataReceived += (_, e) =>
            {
                if (!string.IsNullOrWhiteSpace(e.Data))
                    AppendLog(e.Data!);
            };

            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();

            _ = Task.Run(() =>
            {
                proc.WaitForExit();
                Application.Current.Dispatcher.Invoke(() => StatusText = "Ready");
            });
        }
        catch (Exception ex)
        {
            AppendLog("Launch failed: " + ex.Message);
            StatusText = "Error";
        }
    }

    private string BuildLaunchHint()
    {
        return SelectedLoader == "Fabric"
            ? "Fabric will be installed into the selected instance folder automatically (first run). Put Fabric mods in Mods tab and toggle on/off."
            : "Vanilla downloads happen automatically on first launch for a version. Mods won't load on Vanilla (use Fabric).";
    }

    private void RefreshMods()
    {
        Mods.Clear();
        FilteredMods.Clear();

        if (SelectedInstance is null) return;

        try
        {
            var list = _mods.ScanMods(SelectedInstance);
            foreach (var m in list)
                Mods.Add(new ModRowViewModel(m));

            ApplyModFilter();
        }
        catch (Exception ex)
        {
            AppendLog("Mod scan failed: " + ex.Message);
        }
    }

    private void ApplyModFilter()
    {
        FilteredMods.Clear();
        IEnumerable<ModRowViewModel> query = Mods;

        if (!string.IsNullOrWhiteSpace(ModSearch))
        {
            var s = ModSearch.Trim().ToLowerInvariant();
            query = query.Where(m =>
                m.Name.ToLowerInvariant().Contains(s) ||
                m.FileName.ToLowerInvariant().Contains(s) ||
                m.Author.ToLowerInvariant().Contains(s));
        }

        foreach (var m in query)
            FilteredMods.Add(m);
    }

    private void AddModJar()
    {
        if (SelectedInstance is null) return;

        var dlg = new OpenFileDialog
        {
            Filter = "Jar files (*.jar)|*.jar",
            Title = "Select a mod .jar"
        };

        if (dlg.ShowDialog() == true)
        {
            try
            {
                _mods.AddModJar(SelectedInstance, dlg.FileName);
                RefreshMods();
            }
            catch (Exception ex)
            {
                AppendLog("Add mod failed: " + ex.Message);
            }
        }
    }

    private void ToggleMod(ModRowViewModel? modVm)
    {
        if (SelectedInstance is null || modVm is null) return;

        try
        {
            _mods.SetEnabled(SelectedInstance, modVm.Model, modVm.Enabled);
            // update path & subtitle
            modVm.FilePath = modVm.Model.FilePath;
            ApplyModFilter();
        }
        catch (Exception ex)
        {
            AppendLog("Toggle failed: " + ex.Message);
        }
    }

    private void BrowseJava()
    {
        var dlg = new OpenFileDialog
        {
            Filter = "javaw.exe|javaw.exe|java.exe|java.exe|All files|*.*",
            Title = "Select Java executable (javaw.exe recommended)"
        };

        if (dlg.ShowDialog() == true)
            CustomJavaPath = dlg.FileName;
    }

    private void OpenFolder(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);

        Process.Start(new ProcessStartInfo
        {
            FileName = path,
            UseShellExecute = true
        });
    }

    private void AppendLog(string line)
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            LogText += (string.IsNullOrWhiteSpace(LogText) ? "" : Environment.NewLine) + line;
        });
    }
}
