namespace TNTClient.App.Models;

public sealed class InstanceProfile
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "New Instance";
    public string Loader { get; set; } = "Vanilla"; // Vanilla | Fabric
    public string VanillaVersion { get; set; } = "latest-release";
    public string? InstalledLoaderVersionName { get; set; } // e.g. fabric-loader-...
    public string? LastUsername { get; set; }

    public string RootDir { get; set; } = ""; // resolved at runtime

    public string GameDir => Path.Combine(RootDir, "game");
    public string ModsDir => Path.Combine(GameDir, "mods");
    public string DisabledModsDir => Path.Combine(GameDir, "mods_disabled");
}
