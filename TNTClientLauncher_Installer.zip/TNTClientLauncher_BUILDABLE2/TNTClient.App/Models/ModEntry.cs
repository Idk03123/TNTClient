using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace TNTClient.App.Models;

public sealed class ModEntry
{
    public string FilePath { get; set; } = "";
    public bool Enabled { get; set; }

    public string Name { get; set; } = "Unknown Mod";
    public string Author { get; set; } = "";
    public string Version { get; set; } = "";
    public string ModId { get; set; } = "";

    public string Subtitle
        => string.IsNullOrWhiteSpace(Author)
            ? FileName
            : $"{Author} • {FileName}";

    public string FileName => Path.GetFileName(FilePath);

    // Computed icon for UI
    public ImageSource? IconImage { get; set; }
}
