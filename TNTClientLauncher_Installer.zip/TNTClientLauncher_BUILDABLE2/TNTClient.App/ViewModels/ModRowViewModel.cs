using System.Windows.Media;
using TNTClient.App.Models;
using TNTClient.App.Utils;

namespace TNTClient.App.ViewModels;

public sealed class ModRowViewModel : ObservableObject
{
    private readonly ModEntry _model;

    public ModRowViewModel(ModEntry model) => _model = model;

    public ModEntry Model => _model;

    public string FilePath
    {
        get => _model.FilePath;
        set { _model.FilePath = value; Raise(); Raise(nameof(FileName)); Raise(nameof(Subtitle)); }
    }

    public string FileName => _model.FileName;

    public bool Enabled
    {
        get => _model.Enabled;
        set { _model.Enabled = value; Raise(); }
    }

    public string Name
    {
        get => _model.Name;
        set { _model.Name = value; Raise(); }
    }

    public string Author
    {
        get => _model.Author;
        set { _model.Author = value; Raise(); Raise(nameof(Subtitle)); }
    }

    public string Version
    {
        get => _model.Version;
        set { _model.Version = value; Raise(); }
    }

    public string Subtitle => _model.Subtitle;

    public ImageSource? IconImage => _model.IconImage;
}
