// Global usings to keep the project building cleanly in CLI + WPF XAML temp builds
global using System;
global using System.IO;
global using System.Linq;
global using System.Collections.Generic;
global using System.Threading.Tasks;
global using System.Net.Http;
