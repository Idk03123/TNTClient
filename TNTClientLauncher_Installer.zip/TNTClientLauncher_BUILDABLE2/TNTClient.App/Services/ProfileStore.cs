using System.Text.Json;
using TNTClient.App.Models;

namespace TNTClient.App.Services;

public sealed class ProfileStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public List<InstanceProfile> Load()
    {
        if (!File.Exists(AppPaths.ProfilesJson))
            return new List<InstanceProfile>();

        try
        {
            var json = File.ReadAllText(AppPaths.ProfilesJson);
            var list = JsonSerializer.Deserialize<List<InstanceProfile>>(json, JsonOptions) ?? new List<InstanceProfile>();
            return list;
        }
        catch
        {
            return new List<InstanceProfile>();
        }
    }

    public void Save(IEnumerable<InstanceProfile> profiles)
    {
        var json = JsonSerializer.Serialize(profiles, JsonOptions);
        File.WriteAllText(AppPaths.ProfilesJson, json);
    }
}
