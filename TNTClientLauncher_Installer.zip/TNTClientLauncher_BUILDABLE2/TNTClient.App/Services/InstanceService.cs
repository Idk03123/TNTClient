using TNTClient.App.Models;

namespace TNTClient.App.Services;

public sealed class InstanceService
{
    public InstanceProfile Create(string name)
    {
        var id = Guid.NewGuid().ToString("N");
        var root = Path.Combine(AppPaths.InstancesRoot, SanitizeName(name) + "-" + id.Substring(0, 6));
        Directory.CreateDirectory(root);

        var prof = new InstanceProfile
        {
            Id = id,
            Name = name,
            RootDir = root,
            Loader = "Vanilla",
            VanillaVersion = "latest-release",
        };

        EnsureDirs(prof);
        return prof;
    }

    public void EnsureDirs(InstanceProfile p)
    {
        Directory.CreateDirectory(p.GameDir);
        Directory.CreateDirectory(p.ModsDir);
        Directory.CreateDirectory(p.DisabledModsDir);
        Directory.CreateDirectory(Path.Combine(p.GameDir, "resourcepacks"));
        Directory.CreateDirectory(Path.Combine(p.GameDir, "shaderpacks"));
        Directory.CreateDirectory(Path.Combine(p.GameDir, "config"));
    }

    public void Delete(InstanceProfile p)
    {
        if (Directory.Exists(p.RootDir))
            Directory.Delete(p.RootDir, recursive: true);
    }

    private static string SanitizeName(string name)
    {
        foreach (var c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '-');
        return string.IsNullOrWhiteSpace(name) ? "Instance" : name.Trim();
    }
}
