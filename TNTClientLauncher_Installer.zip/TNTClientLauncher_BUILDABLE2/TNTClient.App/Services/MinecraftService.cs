using System.Diagnostics;
using System.Text.Json;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.ProcessBuilder;
using CmlLib.Core.ModLoaders.FabricMC;
using TNTClient.App.Models;

namespace TNTClient.App.Services;

public sealed class MinecraftService
{
    private const string VersionManifestUrl = "https://launchermeta.mojang.com/mc/game/version_manifest.json";

    public async Task<IReadOnlyList<string>> GetVanillaVersionNamesAsync()
    {
        // Fetch official Mojang version manifest (works without any extra libraries)
        using var http = new HttpClient();
        var json = await http.GetStringAsync(VersionManifestUrl);

        using var doc = JsonDocument.Parse(json);
        var versions = doc.RootElement.GetProperty("versions")
            .EnumerateArray()
            .Select(v => v.GetProperty("id").GetString() ?? "")
            .Where(id => !string.IsNullOrWhiteSpace(id))
            .ToList();

        // Put the newest releases/snapshots first (manifest already is usually newest-first, but keep safe)
        return versions;
    }

    public async Task<string> EnsureFabricInstalledAsync(InstanceProfile instance, string mcVersion, IProgress<string>? log = null)
    {
        // Installs Fabric into this instance folder and returns the new Fabric version name
        var path = new MinecraftPath(instance.GameDir);
        var installer = new FabricInstaller(new HttpClient());

        log?.Report($"Installing Fabric Loader for {mcVersion}...");
        var versionName = await installer.Install(mcVersion, path);
        log?.Report($"Fabric installed: {versionName}");

        return versionName;
    }

    public async Task<Process> CreateProcessAsync(
        InstanceProfile instance,
        string selectedVanillaVersion,
        string loader,
        string username,
        int ramGb,
        string? customJavaPath,
        IProgress<string>? log = null)
    {
        var path = new MinecraftPath(instance.GameDir);
        var launcher = new MinecraftLauncher(path);

        // Decide which version ID to launch
        string versionToLaunch = selectedVanillaVersion;

        if (string.Equals(loader, "Fabric", StringComparison.OrdinalIgnoreCase))
        {
            // Ensure fabric is installed; store installed version name
            var installed = instance.InstalledLoaderVersionName;
            if (string.IsNullOrWhiteSpace(installed) || !installed.Contains(selectedVanillaVersion, StringComparison.OrdinalIgnoreCase))
            {
                installed = await EnsureFabricInstalledAsync(instance, selectedVanillaVersion, log);
                instance.InstalledLoaderVersionName = installed;
            }
            versionToLaunch = installed!;
        }

        // Offline session (singleplayer / offline servers)
        var session = MSession.CreateOfflineSession(string.IsNullOrWhiteSpace(username) ? "Player" : username.Trim());

        var opt = new MLaunchOption
        {
            Session = session,
            MaximumRamMb = ramGb * 1024,
            MinimumRamMb = Math.Min(1024, ramGb * 1024),
        };

        if (!string.IsNullOrWhiteSpace(customJavaPath))
            opt.JavaPath = customJavaPath;

        log?.Report($"Preparing Minecraft process: {versionToLaunch}");

        // In CmlLib.Core 4.x, CreateProcessAsync returns System.Diagnostics.Process
        var process = await launcher.CreateProcessAsync(versionToLaunch, opt);

        // Try to enable output capture (safe defaults)
        try
        {
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.UseShellExecute = false;
        }
        catch
        {
            // If StartInfo is locked or cannot be modified, we still can launch.
        }

        return process;
    }
}
