using System;

namespace TNTClient.App.Services;

public static class AppPaths
{
    public static string DataRoot
    {
        get
        {
            var root = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "TNTClient");
            Directory.CreateDirectory(root);
            return root;
        }
    }

    public static string InstancesRoot
    {
        get
        {
            var p = Path.Combine(DataRoot, "instances");
            Directory.CreateDirectory(p);
            return p;
        }
    }

    public static string ProfilesJson => Path.Combine(DataRoot, "profiles.json");
}
