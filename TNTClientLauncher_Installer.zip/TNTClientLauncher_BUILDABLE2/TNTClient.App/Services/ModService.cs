using System.IO.Compression;
using System.Text.Json;
using System.Windows.Media.Imaging;
using TNTClient.App.Models;

namespace TNTClient.App.Services;

public sealed class ModService
{
    public List<ModEntry> ScanMods(InstanceProfile instance)
    {
        Directory.CreateDirectory(instance.ModsDir);
        Directory.CreateDirectory(instance.DisabledModsDir);

        var list = new List<ModEntry>();

        void addFrom(string dir, bool enabled)
        {
            foreach (var jar in Directory.EnumerateFiles(dir, "*.jar"))
            {
                var entry = new ModEntry
                {
                    FilePath = jar,
                    Enabled = enabled,
                };
                TryReadFabricMetadata(entry);
                list.Add(entry);
            }
        }

        addFrom(instance.ModsDir, true);
        addFrom(instance.DisabledModsDir, false);

        return list.OrderBy(m => m.Name).ToList();
    }

    public void SetEnabled(InstanceProfile instance, ModEntry mod, bool enabled)
    {
        var toDir = enabled ? instance.ModsDir : instance.DisabledModsDir;

        if (!File.Exists(mod.FilePath))
            throw new FileNotFoundException("Mod file not found.", mod.FilePath);

        Directory.CreateDirectory(toDir);

        var target = Path.Combine(toDir, Path.GetFileName(mod.FilePath));
        if (string.Equals(Path.GetFullPath(target), Path.GetFullPath(mod.FilePath), StringComparison.OrdinalIgnoreCase))
        {
            mod.Enabled = enabled;
            return;
        }

        // Avoid overwriting by suffixing
        if (File.Exists(target))
        {
            var baseName = Path.GetFileNameWithoutExtension(target);
            var ext = Path.GetExtension(target);
            var i = 2;
            while (File.Exists(target))
                target = Path.Combine(toDir, $"{baseName} ({i++}){ext}");
        }

        File.Move(mod.FilePath, target);
        mod.FilePath = target;
        mod.Enabled = enabled;
    }

    public void AddModJar(InstanceProfile instance, string sourceJarPath)
    {
        Directory.CreateDirectory(instance.ModsDir);
        var fileName = Path.GetFileName(sourceJarPath);
        var dest = Path.Combine(instance.ModsDir, fileName);

        if (File.Exists(dest))
        {
            var baseName = Path.GetFileNameWithoutExtension(dest);
            var ext = Path.GetExtension(dest);
            var i = 2;
            while (File.Exists(dest))
                dest = Path.Combine(instance.ModsDir, $"{baseName} ({i++}){ext}");
        }

        File.Copy(sourceJarPath, dest);
    }

    private static void TryReadFabricMetadata(ModEntry mod)
    {
        // Fabric mods usually have fabric.mod.json in the jar
        try
        {
            using var zip = ZipFile.OpenRead(mod.FilePath);
            var meta = zip.GetEntry("fabric.mod.json");
            if (meta is null) return;

            using var s = meta.Open();
            using var doc = JsonDocument.Parse(s);
            var root = doc.RootElement;

            if (root.TryGetProperty("id", out var id)) mod.ModId = id.GetString() ?? "";

            if (root.TryGetProperty("name", out var name))
                mod.Name = name.GetString() ?? mod.Name;

            if (root.TryGetProperty("version", out var ver))
                mod.Version = ver.GetString() ?? "";

            if (root.TryGetProperty("authors", out var authors))
            {
                if (authors.ValueKind == JsonValueKind.Array && authors.GetArrayLength() > 0)
                    mod.Author = authors[0].GetString() ?? "";
                else if (authors.ValueKind == JsonValueKind.String)
                    mod.Author = authors.GetString() ?? "";
            }

            // icon can be string path; also can be object map by size in newer mods
            string? iconPath = null;
            if (root.TryGetProperty("icon", out var iconProp))
            {
                if (iconProp.ValueKind == JsonValueKind.String)
                    iconPath = iconProp.GetString();
                else if (iconProp.ValueKind == JsonValueKind.Object)
                {
                    // choose any value, prefer 64 if present
                    if (iconProp.TryGetProperty("64", out var i64) && i64.ValueKind == JsonValueKind.String)
                        iconPath = i64.GetString();
                    else
                    {
                        foreach (var prop in iconProp.EnumerateObject())
                        {
                            if (prop.Value.ValueKind == JsonValueKind.String)
                            {
                                iconPath = prop.Value.GetString();
                                break;
                            }
                        }
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(iconPath))
            {
                var normalized = iconPath!.Replace("\\", "/").TrimStart('/');
                var iconEntry = zip.GetEntry(normalized);
                if (iconEntry != null)
                {
                    using var iconStream = iconEntry.Open();
                    using var ms = new MemoryStream();
                    iconStream.CopyTo(ms);
                    ms.Position = 0;

                    var bmp = new BitmapImage();
                    bmp.BeginInit();
                    bmp.CacheOption = BitmapCacheOption.OnLoad;
                    bmp.StreamSource = ms;
                    bmp.EndInit();
                    bmp.Freeze();

                    mod.IconImage = bmp;
                }
            }
        }
        catch
        {
            // ignore jars without metadata
        }
    }
}
