using System;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace TNTClient.App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();

        // Try load saved UI prefs (theme/resolution/skin) without breaking launcher logic.
        TryLoadUiPrefs();
    }

    private string UiPrefsPath
    {
        get
        {
            // Prefer ViewModel DataRoot if present
            var dc = DataContext;
            var dataRoot = dc?.GetType().GetProperty("DataRoot")?.GetValue(dc) as string;
            if (!string.IsNullOrWhiteSpace(dataRoot))
                return Path.Combine(dataRoot, "ui_prefs.json");

            var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return Path.Combine(local, "TNTClient", "ui_prefs.json");
        }
    }

    private void LoadSkin_Click(object sender, RoutedEventArgs e)
    {
        var ofd = new OpenFileDialog
        {
            Filter = "PNG Image (*.png)|*.png",
            Title = "Select a Minecraft skin PNG"
        };
        if (ofd.ShowDialog() != true) return;

        try
        {
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.UriSource = new Uri(ofd.FileName);
            bmp.EndInit();
            SkinPreview.Source = bmp;

            SaveUiPrefs(skinPath: ofd.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Failed to load skin image:\n" + ex.Message, "TNTClient", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Theme_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // 0 = Dark, 1 = Light
        var idx = ThemeCombo?.SelectedIndex ?? 0;
        ApplyTheme(idx == 1 ? "Light" : "Dark");
        SaveUiPrefs(theme: idx == 1 ? "Light" : "Dark");
    }

    private void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        // Save UI prefs + (if VM has a save method) call it.
        var theme = (ThemeCombo?.SelectedIndex ?? 0) == 1 ? "Light" : "Dark";
        var res = (ResolutionCombo?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Auto";
        SaveUiPrefs(theme: theme, resolution: res);

        // If ViewModel exposes SaveSettings / SaveCommand, invoke it (optional).
        var dc = DataContext;
        if (dc == null) return;

        // Try method SaveSettings()
        var mi = dc.GetType().GetMethod("SaveSettings", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (mi != null && mi.GetParameters().Length == 0)
        {
            try { mi.Invoke(dc, null); }
            catch { /* ignore */ }
        }

        MessageBox.Show(this, "Saved.", "TNTClient", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void ApplyTheme(string theme)
    {
        // Light theme is optional; if brushes exist, recolor them safely.
        try
        {
            var r = Application.Current.Resources;

            if (theme.Equals("Light", StringComparison.OrdinalIgnoreCase))
            {
                SetBrush(r, "BgBrush", "#F6F7FB");
                SetBrush(r, "PanelBrush", "#FFFFFF");
                SetBrush(r, "Panel2Brush", "#EEF1F7");
                SetBrush(r, "StrokeBrush", "#D7DCE7");
                SetBrush(r, "TextBrush", "#111318");
                SetBrush(r, "MutedBrush", "#4B5566");
            }
            else
            {
                // Dark (TNT)
                SetBrush(r, "BgBrush", "#07070A");
                SetBrush(r, "PanelBrush", "#0E0F14");
                SetBrush(r, "Panel2Brush", "#141622");
                SetBrush(r, "StrokeBrush", "#2A0F14");
                SetBrush(r, "TextBrush", "#F5F6FA");
                SetBrush(r, "MutedBrush", "#B1B6C7");
            }
        }
        catch
        {
            // ignore theme failures; launcher should still run
        }
    }

    private static void SetBrush(ResourceDictionary r, string key, string hex)
    {
        if (!r.Contains(key)) return;
        if (r[key] is System.Windows.Media.SolidColorBrush b)
        {
            b.Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hex);
        }
    }

    private void TryLoadUiPrefs()
    {
        try
        {
            if (!File.Exists(UiPrefsPath)) return;

            var json = File.ReadAllText(UiPrefsPath);
            var prefs = JsonSerializer.Deserialize<UiPrefs>(json);
            if (prefs == null) return;

            if (!string.IsNullOrWhiteSpace(prefs.Theme))
            {
                ThemeCombo.SelectedIndex = prefs.Theme.Equals("Light", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
                ApplyTheme(prefs.Theme);
            }

            if (!string.IsNullOrWhiteSpace(prefs.Resolution))
            {
                foreach (var item in ResolutionCombo.Items)
                {
                    if (item is ComboBoxItem cbi && string.Equals(cbi.Content?.ToString(), prefs.Resolution, StringComparison.OrdinalIgnoreCase))
                    {
                        ResolutionCombo.SelectedItem = cbi;
                        break;
                    }
                }
            }

            if (!string.IsNullOrWhiteSpace(prefs.SkinPath) && File.Exists(prefs.SkinPath))
            {
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.UriSource = new Uri(prefs.SkinPath);
                bmp.EndInit();
                SkinPreview.Source = bmp;
            }
        }
        catch
        {
            // ignore
        }
    }

    private void SaveUiPrefs(string? theme = null, string? resolution = null, string? skinPath = null)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(UiPrefsPath)!);

            UiPrefs prefs = new UiPrefs();

            if (File.Exists(UiPrefsPath))
            {
                try
                {
                    prefs = JsonSerializer.Deserialize<UiPrefs>(File.ReadAllText(UiPrefsPath)) ?? new UiPrefs();
                }
                catch { prefs = new UiPrefs(); }
            }

            if (!string.IsNullOrWhiteSpace(theme)) prefs.Theme = theme;
            if (!string.IsNullOrWhiteSpace(resolution)) prefs.Resolution = resolution;
            if (!string.IsNullOrWhiteSpace(skinPath)) prefs.SkinPath = skinPath;

            File.WriteAllText(UiPrefsPath, JsonSerializer.Serialize(prefs, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch
        {
            // ignore
        }
    }

    private sealed class UiPrefs
    {
        public string? Theme { get; set; }
        public string? Resolution { get; set; }
        public string? SkinPath { get; set; }
    }
}
